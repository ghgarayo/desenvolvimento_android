package com.example.atividadepratica

class Compromisso(
    var titulo: String, var data: String, var horaInicio: String,
    var horaFim: String, var descricao: String
)