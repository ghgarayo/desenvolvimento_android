package com.example.aula9

class Pessoa () {
    var nome : String = ""
    var idade : Int = 0

    constructor(nome : String, idade : Int) : this() {
        this.nome = nome
        this.idade = idade
    }

}